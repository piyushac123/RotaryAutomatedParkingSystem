-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 02, 2019 at 05:00 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Sociothon`
--
CREATE DATABASE IF NOT EXISTS `Sociothon` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `Sociothon`;

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `bookID` int(10) NOT NULL,
  `custID` int(10) DEFAULT NULL,
  `locationID` varchar(10) DEFAULT NULL,
  `slotID` varchar(10) DEFAULT NULL,
  `arrivingTime` time DEFAULT NULL,
  `actualArrivingTime` time DEFAULT NULL,
  `stayTime` int(10) DEFAULT NULL,
  `leaveTime` time DEFAULT NULL,
  `bookingDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookID`, `custID`, `locationID`, `slotID`, `arrivingTime`, `actualArrivingTime`, `stayTime`, `leaveTime`, `bookingDate`) VALUES
(1, 1, 'A0', 'A00', '14:00:00', NULL, 4, NULL, '2019-02-07'),
(10, 1, 'A0', 'A00', '03:00:00', NULL, 2, NULL, '2019-02-08'),
(14, 1, 'A0', 'A00', '14:00:00', NULL, 3, NULL, '2019-02-09');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
CREATE TABLE `locations` (
  `locationID` varchar(10) NOT NULL,
  `locationName` varchar(20) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `emptySlot` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`locationID`, `locationName`, `latitude`, `longitude`, `address`, `emptySlot`) VALUES
('A0', 'Bibwewadi', 18.4718, 73.8671, 'near K.K. Market', 10),
('A1', 'Katraj', 18.4575, 73.8677, 'beside Katraj dairy', 10),
('A2', 'Hadapsar', 18.5089, 73.926, 'infront of Chatrapati Sambhaji Udhyan', 10),
('A3', 'Kondhwa', 18.4771, 73.8907, 'infront of Noble Hospital', 10),
('A4', 'Swargate', 18.5018, 73.8636, 'beside Laxmi Narayan theatre', 10),
('A5', 'Deccan', 18.5176, 73.8417, 'near Deccan Gymkhana', 10),
('A6', 'Ambegaon', 19.1132, 73.7327, 'near Katraj Jain Temple', 10),
('A7', 'Dhayari', 18.4422, 73.8096, 'beside Murali Pure Veg', 10),
('A8', 'Shivajinagar', 18.5308, 73.8475, 'infront of Shivajinagar bus stand', 10),
('A9', 'Pune Station', 18.5286, 73.8746, 'infront of pune station', 10);

-- --------------------------------------------------------

--
-- Table structure for table `Registration`
--

DROP TABLE IF EXISTS `Registration`;
CREATE TABLE `Registration` (
  `custID` int(10) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `firstName` varchar(20) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `accno` varchar(20) DEFAULT NULL,
  `expiryDate` date DEFAULT NULL,
  `cvv` int(5) DEFAULT NULL,
  `passcode` int(10) DEFAULT NULL,
  `checkLogin` int(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Registration`
--

INSERT INTO `Registration` (`custID`, `email`, `firstName`, `password`, `accno`, `expiryDate`, `cvv`, `passcode`, `checkLogin`) VALUES
(1, 'aakashchavan@gmail.com', 'Aaskash', 'piyush', '45678jjk', '2019-02-08', 677, 101, 1),
(9, 'krish@gmail.com', 'hgilrhl', 'krishna', '12345678', '2019-02-06', 566, 1234, 1),
(10, 'asd@gmail.com', 'vhv', 'qwe', '1234567', '2019-02-14', 988, 5678, 1),
(11, '', '', '', '', '0000-00-00', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

DROP TABLE IF EXISTS `slots`;
CREATE TABLE `slots` (
  `slotID` varchar(10) NOT NULL,
  `locationID` varchar(10) DEFAULT NULL,
  `confirmBooking` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slots`
--

INSERT INTO `slots` (`slotID`, `locationID`, `confirmBooking`) VALUES
('A00', 'A0', 0),
('A01', 'A0', 0),
('A02', 'A0', 0),
('A03', 'A0', 0),
('A04', 'A0', 0),
('A05', 'A0', 0),
('A06', 'A0', 0),
('A07', 'A0', 0),
('A08', 'A0', 0),
('A09', 'A0', 0),
('A10', 'A1', 0),
('A11', 'A1', 0),
('A12', 'A1', 0),
('A13', 'A1', 0),
('A14', 'A1', 0),
('A15', 'A1', 0),
('A16', 'A1', 0),
('A17', 'A1', 0),
('A18', 'A1', 0),
('A19', 'A1', 0),
('A20', 'A2', 0),
('A21', 'A2', 0),
('A22', 'A2', 0),
('A23', 'A2', 0),
('A24', 'A2', 0),
('A25', 'A2', 0),
('A26', 'A2', 0),
('A27', 'A2', 0),
('A28', 'A2', 0),
('A29', 'A2', 0),
('A30', 'A3', 0),
('A31', 'A3', 0),
('A32', 'A3', 0),
('A33', 'A3', 0),
('A34', 'A3', 0),
('A35', 'A3', 0),
('A36', 'A3', 0),
('A37', 'A3', 0),
('A38', 'A3', 0),
('A39', 'A3', 0),
('A40', 'A4', 0),
('A41', 'A4', 0),
('A42', 'A4', 0),
('A43', 'A4', 0),
('A44', 'A4', 0),
('A45', 'A4', 0),
('A46', 'A4', 0),
('A47', 'A4', 0),
('A48', 'A4', 0),
('A49', 'A4', 0),
('A50', 'A5', 0),
('A51', 'A5', 0),
('A52', 'A5', 0),
('A53', 'A5', 0),
('A54', 'A5', 0),
('A55', 'A5', 0),
('A56', 'A5', 0),
('A57', 'A5', 0),
('A58', 'A5', 0),
('A59', 'A5', 0),
('A60', 'A6', 0),
('A61', 'A6', 0),
('A62', 'A6', 0),
('A63', 'A6', 0),
('A64', 'A6', 0),
('A65', 'A6', 0),
('A66', 'A6', 0),
('A67', 'A6', 0),
('A68', 'A6', 0),
('A69', 'A6', 0),
('A70', 'A7', 0),
('A71', 'A7', 0),
('A72', 'A7', 0),
('A73', 'A7', 0),
('A74', 'A7', 0),
('A75', 'A7', 0),
('A76', 'A7', 0),
('A77', 'A7', 0),
('A78', 'A7', 0),
('A79', 'A7', 0),
('A80', 'A8', 0),
('A81', 'A8', 0),
('A82', 'A8', 0),
('A83', 'A8', 0),
('A84', 'A8', 0),
('A85', 'A8', 0),
('A86', 'A8', 0),
('A87', 'A8', 0),
('A88', 'A8', 0),
('A89', 'A8', 0),
('A90', 'A9', 0),
('A91', 'A9', 0),
('A92', 'A9', 0),
('A93', 'A9', 0),
('A94', 'A9', 0),
('A95', 'A9', 0),
('A96', 'A9', 0),
('A97', 'A9', 0),
('A98', 'A9', 0),
('A99', 'A9', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookID`),
  ADD KEY `custIDConstraint2` (`custID`),
  ADD KEY `locationIDConstraint2` (`locationID`),
  ADD KEY `slotIDConstraint2` (`slotID`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`locationID`);

--
-- Indexes for table `Registration`
--
ALTER TABLE `Registration`
  ADD PRIMARY KEY (`custID`);

--
-- Indexes for table `slots`
--
ALTER TABLE `slots`
  ADD PRIMARY KEY (`slotID`),
  ADD KEY `locationIDConstraint` (`locationID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `Registration`
--
ALTER TABLE `Registration`
  MODIFY `custID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `custIDConstraint2` FOREIGN KEY (`custID`) REFERENCES `Registration` (`custID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `locationIDConstraint2` FOREIGN KEY (`locationID`) REFERENCES `locations` (`locationID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `slotIDConstraint2` FOREIGN KEY (`slotID`) REFERENCES `slots` (`slotID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `slots`
--
ALTER TABLE `slots`
  ADD CONSTRAINT `locationIDConstraint` FOREIGN KEY (`locationID`) REFERENCES `locations` (`locationID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
